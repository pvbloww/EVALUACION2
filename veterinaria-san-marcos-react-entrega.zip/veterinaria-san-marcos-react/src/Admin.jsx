import { useState } from 'react'
import { Alert, Button, Card, Col, Form, Row, Table } from 'react-bootstrap'

const formatoPrecio = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 })
const formularioInicial = { id: '', nombre: '', categoria: '', precio: '', stock: '', descripcion: '', imagen: '', imagenAlt: '' }

export default function Admin({ productos, onGuardar, onEliminar, onCerrarSesion }) {
  const [formulario, setFormulario] = useState(formularioInicial)
  const [editando, setEditando] = useState(false)
  const [mensaje, setMensaje] = useState('')
  const [errores, setErrores] = useState({})

  // Actualiza el campo escrito y quita su mensaje de error para que el formulario sea fácil de corregir.
  function cambiarCampo(evento) {
    const { name, value } = evento.target
    setFormulario((actual) => ({ ...actual, [name]: value }))
    setErrores((actual) => ({ ...actual, [name]: '' }))
  }

  // Revisa cada campo con reglas sencillas y muestra el mensaje junto al campo que debe corregirse.
  function validarFormulario() {
    const nuevosErrores = {}
    // El nombre del producto debe tener al menos 3 caracteres.
    if (formulario.nombre.trim().length < 3) nuevosErrores.nombre = 'Escribe un nombre de al menos 3 caracteres.'
    // La categoría no puede quedar vacía.
    if (!formulario.categoria.trim()) nuevosErrores.categoria = 'Escribe la categoría del producto.'
    // El precio debe ser un número mayor que cero.
    if (!formulario.precio || Number(formulario.precio) <= 0) nuevosErrores.precio = 'Ingresa un precio mayor que 0.'
    // El stock debe ser un número entero igual o mayor que cero.
    if (formulario.stock === '' || !Number.isInteger(Number(formulario.stock)) || Number(formulario.stock) < 0) nuevosErrores.stock = 'Ingresa un stock de 0 o más.'
    // La descripción debe tener al menos 5 caracteres.
    if (formulario.descripcion.trim().length < 5) nuevosErrores.descripcion = 'Escribe una descripción breve (mínimo 5 caracteres).'
    // La ruta de imagen es obligatoria para mostrar la foto del producto.
    if (!formulario.imagen.trim()) nuevosErrores.imagen = 'Escribe la ruta de la imagen del producto.'
    // El texto alternativo describe la imagen para accesibilidad.
    if (!formulario.imagenAlt.trim()) nuevosErrores.imagenAlt = 'Escribe qué aparece en la imagen.'
    return nuevosErrores
  }

  // Evita el envío si hay errores; si todo está correcto, convierte los números y guarda el producto.
  function guardar(evento) {
    evento.preventDefault()
    const nuevosErrores = validarFormulario()
    setErrores(nuevosErrores)
    if (Object.keys(nuevosErrores).length > 0) return

    const producto = {
      ...formulario,
      id: editando ? formulario.id : `PR${Date.now()}`,
      precio: Number(formulario.precio),
      stock: Number(formulario.stock),
    }
    onGuardar(producto)
    setMensaje(editando ? 'Producto actualizado.' : 'Producto agregado.')
    setFormulario(formularioInicial)
    setEditando(false)
    setErrores({})
  }

  // Copia los datos de la fila seleccionada al formulario para editarlos.
  function prepararEdicion(producto) {
    setFormulario({ ...producto, precio: String(producto.precio), stock: String(producto.stock) })
    setErrores({})
    setEditando(true)
    setMensaje('Editando producto. Guarda los cambios en el formulario.')
  }

  // Agrega un mensaje de validación simple debajo del control, sin avisos emergentes del navegador.
  function campoConError(nombre) {
    return errores[nombre] ? <Form.Text className="d-block text-secondary">{errores[nombre]}</Form.Text> : null
  }

  return (
    <main className="section-space"><div className="container">
      <div className="section-heading"><span className="eyebrow">Gestión local de datos</span><h1 className="h2">Administración de productos</h1><p>Agrega, edita o elimina productos del catálogo de demostración.</p><Button variant="outline-secondary" onClick={onCerrarSesion}>Cerrar sesión</Button></div>
      {mensaje && <Alert variant="info" dismissible onClose={() => setMensaje('')}>{mensaje}</Alert>}
      <Row className="g-4">
        <Col lg={4}><Card className="checkout-card"><Card.Body>
          <h2 className="h5">{editando ? 'Editar producto' : 'Agregar producto'}</h2>
          <Form noValidate onSubmit={guardar}>
            <Form.Group className="mb-3"><Form.Label>Nombre</Form.Label><Form.Control name="nombre" value={formulario.nombre} onChange={cambiarCampo} />{campoConError('nombre')}</Form.Group>
            <Form.Group className="mb-3"><Form.Label>Categoría</Form.Label><Form.Control name="categoria" value={formulario.categoria} onChange={cambiarCampo} />{campoConError('categoria')}</Form.Group>
            <Row><Col><Form.Group className="mb-3"><Form.Label>Precio</Form.Label><Form.Control name="precio" type="number" min="1" value={formulario.precio} onChange={cambiarCampo} />{campoConError('precio')}</Form.Group></Col><Col><Form.Group className="mb-3"><Form.Label>Stock</Form.Label><Form.Control name="stock" type="number" min="0" value={formulario.stock} onChange={cambiarCampo} />{campoConError('stock')}</Form.Group></Col></Row>
            <Form.Group className="mb-3"><Form.Label>Descripción</Form.Label><Form.Control as="textarea" rows={2} name="descripcion" value={formulario.descripcion} onChange={cambiarCampo} />{campoConError('descripcion')}</Form.Group>
            <Form.Group className="mb-3"><Form.Label>Ruta de imagen</Form.Label><Form.Control name="imagen" placeholder="/images/producto.png" value={formulario.imagen} onChange={cambiarCampo} />{campoConError('imagen')}</Form.Group>
            <Form.Group className="mb-3"><Form.Label>Texto alternativo de imagen</Form.Label><Form.Control name="imagenAlt" value={formulario.imagenAlt} onChange={cambiarCampo} />{campoConError('imagenAlt')}</Form.Group>
            <Button type="submit" variant="success">{editando ? 'Guardar cambios' : 'Agregar producto'}</Button>{' '}
            {editando && <Button type="button" variant="outline-secondary" onClick={() => { setFormulario(formularioInicial); setEditando(false); setErrores({}); setMensaje('') }}>Cancelar</Button>}
          </Form>
        </Card.Body></Card></Col>
        <Col lg={8}><Card className="checkout-card"><Card.Body>
          <h2 className="h5">Productos registrados ({productos.length})</h2>
          <div className="table-responsive"><Table striped hover className="align-middle"><thead><tr><th>Producto</th><th>Precio</th><th>Stock</th><th>Acciones</th></tr></thead><tbody>
            {productos.map((producto) => <tr key={producto.id}><td>{producto.nombre}<div className="small text-secondary">{producto.categoria}</div></td><td>{formatoPrecio.format(producto.precio)}</td><td>{producto.stock}</td><td className="text-nowrap">{/* En la tabla, outline-success aplica a Editar el borde y el texto verdes de Bootstrap. */}<Button size="sm" variant="outline-success" onClick={() => prepararEdicion(producto)}>Editar</Button>{' '}{/* En esta misma tabla, outline-danger aplica el rojo a Eliminar; el botón también borra el producto por ID. */}<Button size="sm" variant="outline-danger" onClick={() => { onEliminar(producto.id); setMensaje('Producto eliminado.') }}>Eliminar</Button></td></tr>)}
          </tbody></Table></div>
        </Card.Body></Card></Col>
      </Row>
    </div></main>
  )
}


