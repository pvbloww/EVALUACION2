import { useState } from 'react'
import { Alert, Button, Card, Col, Container, Form, Navbar, Nav, Row } from 'react-bootstrap'
import Catalogo from './Catalogo.jsx'
import Carrito from './Carrito.jsx'
import Checkout from './Checkout.jsx'
import Admin from './Admin.jsx'
import AdminLogin from './AdminLogin.jsx'
import UserLogin from './UserLogin.jsx'
import { agregarProductoAlCarrito, obtenerCantidadCarrito } from './data/carrito.js'
import { productosDestacados } from './data/productos.js'
import { obtenerProductos, guardarProductos } from './data/catalogo.js'
import './App.css'

const motivos = [
  { titulo: 'Equipo profesional', texto: 'Médicos veterinarios y personal técnico capacitado para cuidar a tu mascota.' },
  { titulo: 'Vacunación al día', texto: 'Control de vacunas y orientación para mantener su calendario al día.' },
  { titulo: 'Tienda online', texto: 'Encuentra productos y servicios veterinarios desde tu hogar.' },
]

function Encabezado({ vista, carritoCantidad, usuarioAutenticado, onCambiarVista, onAbrirAdmin, onAbrirLoginUsuario, onCerrarSesionUsuario }) {
  return (
    <Navbar expand="lg" className="site-navbar" sticky="top" aria-label="Navegación principal">
      <Container>
        <Navbar.Brand href="#inicio" className="brand-mark" onClick={(evento) => { evento.preventDefault(); onCambiarVista('inicio') }}>Veterinaria San Marcos</Navbar.Brand>
        <Navbar.Toggle aria-controls="navegacion-principal" aria-label="Abrir menú" />
        <Navbar.Collapse id="navegacion-principal">
          <Nav className="me-auto ms-lg-4">
            <Nav.Link href="#inicio" active={vista === 'inicio'} onClick={(evento) => { evento.preventDefault(); onCambiarVista('inicio') }}>Inicio</Nav.Link>
            <Nav.Link href="#catalogo" active={vista === 'catalogo'} onClick={(evento) => { evento.preventDefault(); onCambiarVista('catalogo') }}>Productos</Nav.Link>
            {/* Este enlace abre la vista de ofertas. */}
            <Nav.Link href="#ofertas" onClick={(evento) => { evento.preventDefault(); onCambiarVista('ofertas') }}>Ofertas</Nav.Link>
            <Nav.Link href="#nosotros" onClick={(evento) => { if (vista !== 'inicio') { evento.preventDefault(); onCambiarVista('inicio') } }}>Nosotros</Nav.Link>
          </Nav>
          <div className="nav-actions">
            {/* Iniciar sesión abre el formulario simple para usuarios. */}
            <Button variant="outline-success" size="sm" onClick={usuarioAutenticado ? onCerrarSesionUsuario : onAbrirLoginUsuario}>{usuarioAutenticado ? 'Cerrar sesión' : 'Iniciar sesión'}</Button>
            {/* Admin abre el login separado para gestionar productos. */}
            <Button variant="outline-secondary" size="sm" onClick={onAbrirAdmin}>Admin</Button>
            <Button variant="success" size="sm" onClick={() => onCambiarVista('carrito')}>Carrito ({carritoCantidad})</Button>
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

function TarjetaProducto({ producto, onVerCatalogo }) {
  const precio = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(producto.precioOferta ?? producto.precio)
  return (
    <Card className="product-card h-100">
      <div className="product-illustration"><img src={producto.imagen} alt={producto.imagenAlt} loading="lazy" /></div>
      <Card.Body className="d-flex flex-column">
        <span className="product-category">{producto.precioOferta ? `Oferta · ${producto.categoria}` : producto.categoria}</span>
        <Card.Title as="h3" className="h5 mt-2">{producto.nombre}</Card.Title>
        <Card.Text className="text-secondary">{producto.descripcion}</Card.Text>
        <div className="mt-auto d-flex align-items-center justify-content-between gap-2">
          <strong className="product-price">{precio}</strong>
          <Button variant="success" size="sm" onClick={onVerCatalogo}>Ver catálogo</Button>
        </div>
      </Card.Body>
    </Card>
  )
}

function PieDePagina({ onCambiarVista, onAbrirAdmin }) {
  const [correo, setCorreo] = useState('')
  const [suscrito, setSuscrito] = useState(false)
  const [errorCorreo, setErrorCorreo] = useState('')

  // Revisa el correo del boletín antes de confirmar la suscripción.
  function suscribir(evento) {
    evento.preventDefault()
    // El correo debe incluir @ y un punto; esta regla evita el aviso automático del navegador.
    if (!correo.trim().includes('@') || !correo.trim().includes('.')) {
      setErrorCorreo('Escribe un correo que incluya @ y un punto.')
      return
    }
    setErrorCorreo('')
    setSuscrito(true)
  }

  return (
    <footer className="site-footer">
      <Container>
        <Row className="gy-4 py-5">
          <Col md={4}><h2 className="h5 text-white">Veterinaria San Marcos</h2><p>Rancagua, Región del Libertador Gral. Bernardo O'Higgins.</p></Col>
          <Col md={3}><h2 className="h5 text-white">Enlaces</h2><Nav className="flex-column"><Nav.Link href="#inicio" onClick={(evento) => { evento.preventDefault(); onCambiarVista('inicio') }}>Inicio</Nav.Link><Nav.Link href="#catalogo" onClick={(evento) => { evento.preventDefault(); onCambiarVista('catalogo') }}>Productos</Nav.Link><Nav.Link href="#ofertas" onClick={(evento) => { evento.preventDefault(); onCambiarVista('ofertas') }}>Ofertas</Nav.Link>
            <Nav.Link href="#nosotros" onClick={(evento) => { evento.preventDefault(); onCambiarVista('inicio') }}>Nosotros</Nav.Link></Nav></Col>
          <Col md={5}>
            <h2 className="h5 text-white">Newsletter</h2><p>Recibe novedades y promociones.</p>
            {suscrito ? <Alert variant="success" className="mb-0">¡Gracias! Te enviaremos novedades a {correo}.</Alert> : (
              <Form noValidate onSubmit={suscribir} className="newsletter-form">
                <Form.Label htmlFor="newsletter-correo" className="visually-hidden">Correo electrónico</Form.Label>
                <Form.Control id="newsletter-correo" type="text" placeholder="Tu correo" value={correo} onChange={(evento) => { setCorreo(evento.target.value); setErrorCorreo('') }} />
                {errorCorreo && <Form.Text className="d-block text-white">{errorCorreo}</Form.Text>}
                <Button type="submit" variant="warning">Unirme</Button>
              </Form>
            )}
          </Col>
        </Row>
        <div className="footer-bottom">© {new Date().getFullYear()} Veterinaria San Marcos. Proyecto académico DSY1104.</div>
      </Container>
    </footer>
  )
}

function Inicio({ onVerCatalogo }) {
  return (
    <main id="inicio">
      <section className="hero-section">
        <Container className="py-5"><Row className="align-items-center g-4 py-lg-4">
          <Col lg={6}><span className="eyebrow">Cuidado veterinario en Rancagua</span><h1>Cuidamos a tu mascota como parte de tu familia</h1><p className="hero-copy">En Veterinaria San Marcos ofrecemos consultas, vacunación, cirugías y productos de calidad para perros, gatos y otras mascotas. Agenda tu hora o compra en línea de forma simple.</p><Button variant="success" size="lg" onClick={onVerCatalogo}>Ver productos</Button></Col>
          <Col lg={6}><img className="hero-photo" src="/images/clinica-hero.png" alt="Veterinaria atendiendo a un perro y un gato en la clínica" /></Col>
        </Row></Container>
      </section>
      <section id="productos" className="section-space"><Container>
        <div className="section-heading"><span className="eyebrow">Para su bienestar</span><h2>Productos destacados</h2><p>Una muestra de nuestro catálogo de vacunas, medicamentos y servicios.</p></div>
        <Row className="g-4">{productosDestacados.map((producto) => <Col key={producto.id} sm={6} lg={4}><TarjetaProducto producto={producto} onVerCatalogo={onVerCatalogo} /></Col>)}</Row>
        <div className="text-center mt-4"><Button variant="outline-success" onClick={onVerCatalogo}>Ver todo el catálogo</Button></div>
      </Container></section>
      <section id="nosotros" className="section-space why-section"><Container>
        <div className="section-heading"><span className="eyebrow">Nuestro compromiso</span><h2>¿Por qué elegirnos?</h2></div>
        <Row className="g-4">{motivos.map((motivo) => <Col md={4} key={motivo.titulo}><Card className="reason-card h-100 text-center"><Card.Body><Card.Title as="h3" className="h5">{motivo.titulo}</Card.Title><Card.Text>{motivo.texto}</Card.Text></Card.Body></Card></Col>)}</Row>
      </Container></section>
    </main>
  )
}

function App() {
  const [vista, setVista] = useState('inicio')
  const [adminAutenticado, setAdminAutenticado] = useState(false)
  const [usuarioAutenticado, setUsuarioAutenticado] = useState(false)
  const [carritoCantidad, setCarritoCantidad] = useState(() => obtenerCantidadCarrito())
  const [listaProductos, setListaProductos] = useState(() => obtenerProductos())

  // Guarda la lista en memoria y en el navegador para que persista al recargar.
  function actualizarProductos(nuevaLista) { setListaProductos(nuevaLista); guardarProductos(nuevaLista) }
  function agregarAlCarrito(producto) { setCarritoCantidad(agregarProductoAlCarrito(producto.id)) }
  // Solo abre el panel si la sesión administrativa ya inició.
  function abrirAdmin() { setVista(adminAutenticado ? 'admin' : 'admin-login') }
  function cerrarSesionAdmin() { setAdminAutenticado(false); setVista('inicio') }

  let contenido
  // Esta ruta muestra el inicio de sesión simulado para el usuario.
  if (vista === 'user-login') {
    contenido = <UserLogin onLogin={() => { setUsuarioAutenticado(true); setVista('inicio') }} onVolver={() => setVista('inicio')} />
  } else if (vista === 'admin-login') {
    contenido = <AdminLogin onLogin={() => { setAdminAutenticado(true); setVista('admin') }} onVolver={() => setVista('inicio')} />
  } else if (vista === 'admin') {
    contenido = adminAutenticado
      ? <Admin productos={listaProductos} onGuardar={(producto) => actualizarProductos(listaProductos.some((item) => item.id === producto.id) ? listaProductos.map((item) => item.id === producto.id ? producto : item) : [...listaProductos, producto])} onEliminar={(id) => actualizarProductos(listaProductos.filter((producto) => producto.id !== id))} onCerrarSesion={cerrarSesionAdmin} />
      : <AdminLogin onLogin={() => { setAdminAutenticado(true); setVista('admin') }} onVolver={() => setVista('inicio')} />
  } else if (vista === 'catalogo') {
    contenido = <Catalogo productos={listaProductos} onAgregar={agregarAlCarrito} onVolver={() => setVista('inicio')} />
  } else if (vista === 'ofertas') {
    contenido = <Catalogo productos={listaProductos} onAgregar={agregarAlCarrito} onVolver={() => setVista('inicio')} soloOfertas />
  } else if (vista === 'carrito') {
    contenido = <Carrito productos={listaProductos} onVolver={() => setVista('catalogo')} onContinuarCompra={() => setVista('checkout')} onCarritoActualizado={() => setCarritoCantidad(obtenerCantidadCarrito())} />
  } else if (vista === 'checkout') {
    contenido = <Checkout productos={listaProductos} onVolver={() => setVista('carrito')} onVerCatalogo={() => setVista('catalogo')} onPedidoConfirmado={() => setCarritoCantidad(obtenerCantidadCarrito())} />
  } else {
    contenido = <Inicio onVerCatalogo={() => setVista('catalogo')} />
  }

  return (
    <>
      <Encabezado vista={vista} carritoCantidad={carritoCantidad} usuarioAutenticado={usuarioAutenticado} onCambiarVista={setVista} onAbrirAdmin={abrirAdmin} onAbrirLoginUsuario={() => setVista("user-login")} onCerrarSesionUsuario={() => setUsuarioAutenticado(false)} />
      {/* Esta condición decide cuál pantalla mostrar según la vista seleccionada. */}
      {contenido}
      <PieDePagina onCambiarVista={setVista} onAbrirAdmin={abrirAdmin} />
    </>
  )
}

export default App


















