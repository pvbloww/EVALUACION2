import { useState } from 'react'
import { Alert, Button, Card, Container, Form } from 'react-bootstrap'

const claveCuentaUsuario = 'veterinaria-usuario-demo'

// Este formulario simula el registro y el inicio de sesión sin servidor.
export default function UserLogin({ onLogin, onVolver }) {
  const [modo, setModo] = useState('login')
  const [nombre, setNombre] = useState('')
  const [correo, setCorreo] = useState('')
  const [clave, setClave] = useState('')
  const [errores, setErrores] = useState({})
  const [mensaje, setMensaje] = useState('')

  // Comprueba datos básicos y muestra las explicaciones debajo de cada campo.
  function validarFormulario() {
    const nuevosErrores = {}
    // En el registro, el nombre debe tener al menos 3 caracteres.
    if (modo === 'registro' && nombre.trim().length < 3) nuevosErrores.nombre = 'Escribe tu nombre (mínimo 3 caracteres).'
    // El correo debe incluir @ y un punto.
    if (!correo.trim().includes('@') || !correo.trim().includes('.')) nuevosErrores.correo = 'El correo debe incluir @ y un punto.'
    // La contraseña debe tener al menos 4 caracteres para esta demostración.
    if (clave.trim().length < 4) nuevosErrores.clave = 'La contraseña debe tener al menos 4 caracteres.'
    return nuevosErrores
  }

  // Guarda los datos de registro en el navegador y luego permite iniciar sesión con ellos.
  function registrarUsuario() {
    const cuenta = { nombre: nombre.trim(), correo: correo.trim(), clave }
    localStorage.setItem(claveCuentaUsuario, JSON.stringify(cuenta))
    setModo('login')
    setNombre('')
    setClave('')
    setMensaje('Cuenta creada. Ahora inicia sesión con tu correo y contraseña.')
  }

  // Compara los datos ingresados con la cuenta guardada durante el registro.
  function iniciarSesion() {
    const cuentaGuardada = localStorage.getItem(claveCuentaUsuario)
    const cuenta = cuentaGuardada ? JSON.parse(cuentaGuardada) : null
    if (cuenta && cuenta.correo === correo.trim() && cuenta.clave === clave) onLogin()
    else setMensaje('No encontramos esa cuenta. Regístrate o revisa tus datos.')
  }

  // Evita los avisos emergentes del navegador y ejecuta registro o ingreso según el modo seleccionado.
  function enviarFormulario(evento) {
    evento.preventDefault()
    const nuevosErrores = validarFormulario()
    setErrores(nuevosErrores)
    setMensaje('')
    if (Object.keys(nuevosErrores).length > 0) return
    if (modo === 'registro') registrarUsuario()
    else iniciarSesion()
  }

  function cambiarModo(nuevoModo) {
    setModo(nuevoModo)
    setErrores({})
    setMensaje('')
  }

  return (
    <main className="section-space"><Container className="d-flex justify-content-center">
      <Card className="checkout-card w-100" style={{ maxWidth: '460px' }}><Card.Body className="p-4">
        <span className="eyebrow">Acceso de usuario</span><h1 className="h3 mt-2">{modo === 'registro' ? 'Crear cuenta' : 'Iniciar sesión'}</h1>
        <p className="text-secondary">Cuenta de demostración guardada en este navegador.</p>
        {mensaje && <Alert variant="info" role="status">{mensaje}</Alert>}
        <Form noValidate onSubmit={enviarFormulario}>
          {modo === 'registro' && <Form.Group className="mb-3"><Form.Label>Nombre completo</Form.Label><Form.Control type="text" value={nombre} onChange={(evento) => { setNombre(evento.target.value); setErrores((actual) => ({ ...actual, nombre: '' })) }} />{errores.nombre && <Form.Text className="d-block text-secondary">{errores.nombre}</Form.Text>}</Form.Group>}
          <Form.Group className="mb-3"><Form.Label>Correo electrónico</Form.Label><Form.Control type="text" value={correo} onChange={(evento) => { setCorreo(evento.target.value); setErrores((actual) => ({ ...actual, correo: '' })) }} autoComplete="username" />{errores.correo && <Form.Text className="d-block text-secondary">{errores.correo}</Form.Text>}</Form.Group>
          <Form.Group className="mb-3"><Form.Label>Contraseña</Form.Label><Form.Control type="password" value={clave} onChange={(evento) => { setClave(evento.target.value); setErrores((actual) => ({ ...actual, clave: '' })) }} autoComplete={modo === 'registro' ? 'new-password' : 'current-password'} />{errores.clave && <Form.Text className="d-block text-secondary">{errores.clave}</Form.Text>}</Form.Group>
          <Button type="submit" variant="success" className="me-2">{modo === 'registro' ? 'Registrarme' : 'Ingresar'}</Button>
          <Button type="button" variant="outline-secondary" onClick={() => cambiarModo(modo === 'registro' ? 'login' : 'registro')}>{modo === 'registro' ? 'Ya tengo cuenta' : 'Crear cuenta'}</Button>{' '}
          <Button type="button" variant="link" onClick={onVolver}>Volver</Button>
        </Form>
      </Card.Body></Card>
    </Container></main>
  )
}
