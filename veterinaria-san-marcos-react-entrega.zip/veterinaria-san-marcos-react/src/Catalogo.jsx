import { useMemo, useState } from 'react'
import { Alert, Button, Card, Col, Form, Row } from 'react-bootstrap'
import { productos as productosIniciales } from './data/productos.js'

const formatoPrecio = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 })

function TarjetaProducto({ producto, onAgregar }) {
  return (
    <Card className="product-card h-100">
      <div className="product-illustration"><img src={producto.imagen} alt={producto.imagenAlt} loading="lazy" /></div>
      <Card.Body className="d-flex flex-column">
        <span className="product-category">{producto.precioOferta ? `Oferta · ${producto.categoria}` : producto.categoria}</span>
        <Card.Title as="h3" className="h5 mt-2">{producto.nombre}</Card.Title>
        <Card.Text className="text-secondary">{producto.descripcion}</Card.Text>
        <div className="mt-auto d-flex align-items-center justify-content-between gap-2">
          <strong className="product-price">{formatoPrecio.format(producto.precioOferta ?? producto.precio)}</strong>
          <Button variant="success" size="sm" onClick={() => onAgregar(producto)} disabled={producto.stock < 1}>Añadir al carrito</Button>
        </div>
      </Card.Body>
    </Card>
  )
}

export default function Catalogo({ onAgregar, onVolver, soloOfertas = false, productos = productosIniciales }) {
  const [categoriaActiva, setCategoriaActiva] = useState('Todos')
  const [busqueda, setBusqueda] = useState('')
  const [mensaje, setMensaje] = useState('')
  const categorias = useMemo(() => ['Todos', ...new Set(productos.map((producto) => producto.categoria))], [])
  // soloOfertas limita los resultados a productos con precio promocional.
  const resultados = productos.filter((producto) => {
    const coincideCategoria = categoriaActiva === 'Todos' || producto.categoria === categoriaActiva
    const termino = busqueda.trim().toLocaleLowerCase('es-CL')
    const coincideTexto = `${producto.nombre} ${producto.categoria} ${producto.descripcion}`.toLocaleLowerCase('es-CL').includes(termino)
    return coincideCategoria && coincideTexto && (!soloOfertas || Boolean(producto.precioOferta))
  })

  function agregar(producto) {
    onAgregar(producto)
    setMensaje(`${producto.nombre} se agregó al carrito.`)
  }

  return (
    <main className="catalog-page section-space">
      <div className="container">
        <div className="section-heading">
          <span className="eyebrow">Todo para su bienestar</span>
          <h1 className="h2">{soloOfertas ? 'Ofertas' : 'Productos'}</h1>
          <p>{soloOfertas ? 'Productos seleccionados con precio promocional.' : 'Vacunas, medicamentos, antiparasitarios y servicios para el cuidado de tu mascota.'}</p>
        </div>
        <div className="catalog-tools">
          <Form.Group className="catalog-search">
            <Form.Label htmlFor="buscar-productos" className="visually-hidden">Buscar productos</Form.Label>
            <Form.Control id="buscar-productos" type="search" placeholder="Buscar por nombre o categoría" value={busqueda} onChange={(evento) => setBusqueda(evento.target.value)} />
          </Form.Group>
          <div className="catalog-filters" role="group" aria-label="Filtrar productos por categoría">
            {categorias.map((categoria) => <Button key={categoria} size="sm" variant={categoriaActiva === categoria ? 'success' : 'outline-success'} aria-pressed={categoriaActiva === categoria} onClick={() => setCategoriaActiva(categoria)}>{categoria}</Button>)}
          </div>
        </div>
        {mensaje && <Alert variant="success" dismissible onClose={() => setMensaje('')} role="status">{mensaje}</Alert>}
        <p className="catalog-count" aria-live="polite">{resultados.length} {resultados.length === 1 ? 'producto encontrado' : 'productos encontrados'}</p>
        {resultados.length ? (
          <Row className="g-4">{resultados.map((producto) => <Col key={producto.id} sm={6} lg={4}><TarjetaProducto producto={producto} onAgregar={agregar} /></Col>)}</Row>
        ) : <Alert variant="light" className="text-center">No encontramos productos que coincidan con la búsqueda.</Alert>}
        <div className="text-center mt-5"><Button variant="outline-success" onClick={onVolver}>Volver al inicio</Button></div>
      </div>
    </main>
  )
}






