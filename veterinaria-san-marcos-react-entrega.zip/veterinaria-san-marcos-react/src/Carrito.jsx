import { useState } from 'react'
import { Alert, Button, Card, Col, Container, Form, Row } from 'react-bootstrap'
import { obtenerCarrito, quitarProductoDelCarrito, actualizarCantidadProducto, vaciarCarrito } from './data/carrito.js'

const formatoPrecio = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 })

function cargarLineas(productos) {
  return obtenerCarrito().map((linea) => ({
    ...linea,
    producto: productos.find((producto) => producto.id === linea.productoId),
  })).filter((linea) => linea.producto)
}

export default function Carrito({ onVolver, onContinuarCompra, onCarritoActualizado, productos }) {
  const [lineas, setLineas] = useState(() => cargarLineas(productos))
  const [mensaje, setMensaje] = useState('')
  const total = lineas.reduce((suma, linea) => suma + (linea.producto.precioOferta ?? linea.producto.precio) * linea.cantidad, 0)

  function sincronizar() {
    setLineas(cargarLineas(productos))
    onCarritoActualizado()
  }

  function cambiarCantidad(productoId, cantidad) {
    const cantidadValida = Math.min(99, Math.max(1, Number(cantidad) || 1))
    actualizarCantidadProducto(productoId, cantidadValida)
    sincronizar()
  }

  // Quita el producto del almacenamiento y actualiza la pantalla del carrito.
  function quitar(productoId) {
    quitarProductoDelCarrito(productoId)
    sincronizar()
  }

  // Vacía todos los productos guardados en el carrito.
  function limpiar() {
    vaciarCarrito()
    setMensaje('El carrito se vació.')
    sincronizar()
  }

  return (
    <main className="cart-page section-space">
      <Container>
        <div className="section-heading">
          <span className="eyebrow">Tu compra</span>
          <h1 className="h2">Carrito de compras</h1>
          <p>Revisa los productos antes de continuar.</p>
        </div>
        {mensaje && <Alert variant="success" dismissible onClose={() => setMensaje('')}>{mensaje}</Alert>}
        {lineas.length === 0 ? (
          <Card className="empty-cart text-center"><Card.Body><h2 className="h4">Tu carrito está vacío</h2><p className="text-secondary">Explora el catálogo para encontrar lo que necesita tu mascota.</p><Button variant="success" onClick={onVolver}>Ir a productos</Button></Card.Body></Card>
        ) : (
          <Row className="g-4 align-items-start">
            <Col lg={8}>
              <div className="cart-lines">
                {lineas.map(({ producto, cantidad }) => (
                  <Card className="cart-line" key={producto.id}>
                    <Row className="g-0 align-items-center">
                      <Col xs={3} sm={2}><div className="cart-product-icon"><img src={producto.imagen} alt={producto.imagenAlt} loading="lazy" /></div></Col>
                      <Col xs={9} sm={10}><Card.Body>
                        <div className="d-flex flex-column flex-md-row justify-content-between gap-3">
                          <div><span className="product-category">{producto.categoria}</span><h2 className="h5 mt-1 mb-1">{producto.nombre}</h2><p className="text-secondary small mb-0">{formatoPrecio.format(producto.precioOferta ?? producto.precio)} por unidad</p></div>
                          <div className="cart-line-actions">
                            <Form.Group>
                              <Form.Label htmlFor={`cantidad-${producto.id}`} className="small">Cantidad</Form.Label>
                              <Form.Control id={`cantidad-${producto.id}`} type="number" min="1" max="99" value={cantidad} onChange={(evento) => cambiarCantidad(producto.id, evento.target.value)} aria-label={`Cantidad de ${producto.nombre}`} />
                            </Form.Group>
                            <strong className="cart-line-total">{formatoPrecio.format((producto.precioOferta ?? producto.precio) * cantidad)}</strong>
                            
                            {/* Quitar: elimina del carrito el producto usando su ID. */}
                            <Button variant="link" className="remove-item" onClick={() => quitar(producto.id)} aria-label={`Quitar ${producto.nombre} del carrito`}>Quitar</Button>
                          </div>
                        </div>
                      </Card.Body></Col>
                    </Row>
                  </Card>
                ))}
              </div>
              {/* Vacía el carrito completo. */}
              <Button variant="outline-secondary" className="mt-3" onClick={limpiar}>Vaciar carrito</Button>
            </Col>
            <Col lg={4}>
              <Card className="cart-summary"><Card.Body>
                <h2 className="h5">Resumen de compra</h2>
                <div className="cart-summary-row"><span>Productos</span><span>{lineas.reduce((cantidad, linea) => cantidad + linea.cantidad, 0)}</span></div>
                <div className="cart-summary-row cart-total"><span>Total</span><span>{formatoPrecio.format(total)}</span></div>
                <p className="small text-secondary">El despacho se calculará en el siguiente paso.</p>
                {/* Abre el formulario de checkout. */}
                <Button variant="success" className="w-100" onClick={onContinuarCompra}>Continuar compra</Button>
                {/* Seguir comprando: onVolver regresa al catálogo. */}
                <Button variant="link" className="w-100 mt-2" onClick={onVolver}>Seguir comprando</Button>
              </Card.Body></Card>
            </Col>
          </Row>
        )}
      </Container>
    </main>
  )
}









