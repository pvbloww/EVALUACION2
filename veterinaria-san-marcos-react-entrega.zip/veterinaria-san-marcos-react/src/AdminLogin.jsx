import { useState } from 'react'
import { Alert, Button, Card, Container, Form } from 'react-bootstrap'

// Credenciales fijas solo para demostrar el acceso; no reemplazan autenticación de servidor.
const credencialesDemo = { correo: 'admin@sanmarcos.cl', clave: 'admin123' }

export default function AdminLogin({ onLogin, onVolver }) {
  const [correo, setCorreo] = useState('')
  const [clave, setClave] = useState('')
  const [errores, setErrores] = useState({})
  const [error, setError] = useState('')

  // Comprueba los campos antes de intentar entrar y muestra los errores debajo de cada uno.
  function iniciarSesion(evento) {
    evento.preventDefault()
    const nuevosErrores = {}
    // El correo debe incluir arroba y punto para tener un formato básico.
    if (!correo.trim().includes('@') || !correo.trim().includes('.')) nuevosErrores.correo = 'Escribe un correo que incluya @ y un punto.'
    // La contraseña no puede quedar vacía.
    if (!clave.trim()) nuevosErrores.clave = 'Escribe la contraseña.'
    setErrores(nuevosErrores)
    setError('')
    if (Object.keys(nuevosErrores).length > 0) return

    // Compara los datos ingresados con las credenciales de demostración.
    if (correo === credencialesDemo.correo && clave === credencialesDemo.clave) onLogin()
    // Si los datos no coinciden, muestra un aviso general sin revelar cuál dato falló.
    else setError('Correo o contraseña incorrectos.')
  }

  return (
    <main className="section-space"><Container className="d-flex justify-content-center">
      <Card className="checkout-card w-100" style={{ maxWidth: '460px' }}><Card.Body className="p-4">
        <span className="eyebrow">Acceso restringido</span><h1 className="h3 mt-2">Inicio de sesión de administración</h1>
        <p className="text-secondary">Ingresa con la cuenta de demostración para gestionar el catálogo.</p>
        {/* Muestra el aviso general que se prepara cuando las credenciales no coinciden. */}
        {error && <Alert variant="warning" role="alert">{error}</Alert>}
        <Form noValidate onSubmit={iniciarSesion}>
          <Form.Group className="mb-3"><Form.Label>Correo de administrador</Form.Label><Form.Control type="text" value={correo} onChange={(evento) => { setCorreo(evento.target.value); setErrores((actual) => ({ ...actual, correo: '' })) }} autoComplete="username" />{errores.correo && <Form.Text className="d-block text-secondary">{errores.correo}</Form.Text>}</Form.Group>
          <Form.Group className="mb-3"><Form.Label>Contraseña</Form.Label><Form.Control type="password" value={clave} onChange={(evento) => { setClave(evento.target.value); setErrores((actual) => ({ ...actual, clave: '' })) }} autoComplete="current-password" />{errores.clave && <Form.Text className="d-block text-secondary">{errores.clave}</Form.Text>}</Form.Group>
          <div className="small text-secondary mb-3">Cuenta para la presentación: admin@sanmarcos.cl · admin123</div>
          <Button type="submit" variant="success" className="me-2">Ingresar</Button><Button type="button" variant="outline-secondary" onClick={onVolver}>Volver</Button>
        </Form>
      </Card.Body></Card>
    </Container></main>
  )
}

