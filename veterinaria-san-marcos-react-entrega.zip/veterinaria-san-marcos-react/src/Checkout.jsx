import { useState } from 'react'
import { Alert, Button, Card, Col, Container, Form, Row } from 'react-bootstrap'
import { obtenerCarrito, vaciarCarrito } from './data/carrito.js'
import { validarDatos } from './data/validaciones.js'

const formatoPrecio = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 })
const datosIniciales = { nombre: '', correo: '', telefono: '', direccion: '', comuna: '' }


export default function Checkout({ onVolver, onVerCatalogo, onPedidoConfirmado, productos }) {
  const [tipoEntrega, setTipoEntrega] = useState('retiro')
  const [etapa, setEtapa] = useState('datos')
  const [datos, setDatos] = useState(datosIniciales)
  const [errores, setErrores] = useState({})
  const [pedido, setPedido] = useState(null)
  const [numeroPedido, setNumeroPedido] = useState('')
  const lineas = obtenerCarrito().map((linea) => ({ ...linea, producto: productos.find((producto) => producto.id === linea.productoId) })).filter((linea) => linea.producto)
  const subtotal = lineas.reduce((suma, linea) => suma + (linea.producto.precioOferta ?? linea.producto.precio) * linea.cantidad, 0)
  const costoDespacho = tipoEntrega === 'despacho' ? 2990 : 0

  function cambiarDato(evento) {
    const { name, value } = evento.target
    setDatos((actuales) => ({ ...actuales, [name]: value }))
    setErrores((actuales) => ({ ...actuales, [name]: '' }))
  }

  // Al pulsar Revisar datos valida el estado; si no hay errores, guarda el pedido y muestra el resumen.
function enviarFormulario(evento) {
    evento.preventDefault()
    const nuevosErrores = validarDatos(datos, tipoEntrega)
    setErrores(nuevosErrores)
    if (Object.keys(nuevosErrores).length === 0) {
      setPedido({ ...datos, tipoEntrega, lineas, subtotal, costoDespacho, total: subtotal + costoDespacho })
      setEtapa('resumen')
    }
  }

  function cambiarEntrega(entrega) {
    setTipoEntrega(entrega)
    setErrores((actuales) => ({ ...actuales, direccion: '', comuna: '' }))
  }

  // Confirmación simulada: limpia el carrito local y actualiza su contador.
function confirmarPedido() {
    setNumeroPedido(`VSM-${Date.now().toString().slice(-6)}`)
    vaciarCarrito()
    onPedidoConfirmado()
    setEtapa('confirmado')
  }

  // Vista de resultado exitoso, sin realizar pagos reales.
  if (etapa === 'confirmado' && pedido) {
    return <main className="checkout-page section-space"><Container><Card className="checkout-card mx-auto" style={{ maxWidth: 720 }}><Card.Body className="p-4 p-md-5 text-center"><span className="eyebrow">Compra simulada</span><h1 className="h2 mt-2">¡Pedido recibido!</h1><p>Este proyecto no procesa pagos; el pedido se registra solo como demostración.</p><p className="fw-semibold">Número de pedido: {numeroPedido}</p><p className="mb-4">Total: {formatoPrecio.format(pedido.total)}</p><Button variant="success" onClick={onVerCatalogo}>Volver al catálogo</Button></Card.Body></Card></Container></main>
  }

  // Vista de resultado fallido simulada; permite reintentar conservando el carrito.
  if (etapa === 'fallido' && pedido) {
    return <main className="checkout-page section-space"><Container><Card className="checkout-card mx-auto" style={{ maxWidth: 720 }}><Card.Body className="p-4 p-md-5 text-center"><span className="eyebrow">Compra simulada</span><h1 className="h2 mt-2">No se pudo completar el pago</h1><p>No se realizó ningún cobro. El carrito se conserva para que puedas intentarlo nuevamente.</p><p className="fw-semibold">Total del pedido: {formatoPrecio.format(pedido.total)}</p><div className="d-flex flex-wrap justify-content-center gap-2"><Button variant="success" onClick={() => setEtapa('resumen')}>Intentar nuevamente</Button><Button variant="outline-secondary" onClick={onVolver}>Volver al carrito</Button></div></Card.Body></Card></Container></main>
  }

  // Vista previa del pedido para revisar antes de confirmar.
  if (etapa === 'resumen' && pedido) {
    return <main className="checkout-page section-space"><Container>
      <div className="section-heading"><span className="eyebrow">Paso 2 de compra</span><h1 className="h2">Resumen del pedido</h1><p>Revisa tus datos antes de confirmar.</p></div>
      <Row className="g-4 align-items-start">
        <Col lg={7}><Card className="checkout-card"><Card.Body><h2 className="h5">Datos de contacto</h2><p className="mb-1">{pedido.nombre}</p><p className="mb-1">{pedido.correo}</p><p>{pedido.telefono}</p><h2 className="h5 mt-4">Entrega</h2><p>{pedido.tipoEntrega === 'retiro' ? 'Retiro en tienda' : `Despacho a ${pedido.direccion}, ${pedido.comuna}`}</p><div className="d-flex flex-wrap gap-2"><Button variant="outline-secondary" onClick={() => setEtapa('datos')}>Volver a editar</Button><Button variant="success" onClick={confirmarPedido}>Confirmar compra simulada</Button>{/* Demuestra el resultado fallido solicitado en la pauta; setEtapa('fallido') muestra esa pantalla. */}<Button variant="outline-danger" onClick={() => setEtapa('fallido')}>Simular pago rechazado</Button></div></Card.Body></Card></Col>
        <Col lg={5}><Card className="cart-summary"><Card.Body><h2 className="h5">Productos</h2>{pedido.lineas.map(({ producto, cantidad }) => <div className="checkout-item" key={producto.id}><span>{producto.nombre} × {cantidad}</span><strong>{formatoPrecio.format((producto.precioOferta ?? producto.precio) * cantidad)}</strong></div>)}<div className="cart-summary-row"><span>Subtotal</span><span>{formatoPrecio.format(pedido.subtotal)}</span></div><div className="cart-summary-row"><span>Entrega</span><span>{pedido.costoDespacho ? formatoPrecio.format(pedido.costoDespacho) : 'Gratis'}</span></div><div className="cart-summary-row cart-total"><span>Total</span><span>{formatoPrecio.format(pedido.total)}</span></div></Card.Body></Card></Col>
      </Row>
    </Container></main>
  }

  if (lineas.length === 0) {
    return <main className="checkout-page section-space"><Container><Alert variant="warning">El carrito está vacío. Agrega productos antes de iniciar la compra.</Alert><Button variant="success" onClick={onVerCatalogo}>Ir al catálogo</Button></Container></main>
  }

  return <main className="checkout-page section-space"><Container>
    <div className="section-heading"><span className="eyebrow">Paso 1 de compra</span><h1 className="h2">Datos y entrega</h1><p>Completa tus datos para preparar el pedido.</p></div>
    
    <Row className="g-4 align-items-start">
      <Col lg={7}><Card className="checkout-card"><Card.Body>{/* noValidate evita el mensaje nativo; los errores se muestran con las reglas de validarDatos. */}
      <Form noValidate onSubmit={enviarFormulario}>
        <h2 className="h5 mb-3">Datos de contacto</h2><Row className="g-3">
          <Col md={6}><Form.Group controlId="checkout-nombre"><Form.Label>Nombre completo</Form.Label><Form.Control name="nombre" autoComplete="name" value={datos.nombre} onChange={cambiarDato} />{errores.nombre && <Form.Text className="d-block text-secondary small">{errores.nombre}</Form.Text>}</Form.Group></Col>
          <Col md={6}><Form.Group controlId="checkout-correo"><Form.Label>Correo electrónico</Form.Label><Form.Control name="correo" type="email" autoComplete="email" value={datos.correo} onChange={cambiarDato} />{errores.correo && <Form.Text className="d-block text-secondary small">{errores.correo}</Form.Text>}</Form.Group></Col>
          <Col md={6}><Form.Group controlId="checkout-telefono"><Form.Label>Teléfono</Form.Label><Form.Control name="telefono" type="tel" autoComplete="tel" value={datos.telefono} onChange={cambiarDato} />{errores.telefono && <Form.Text className="d-block text-secondary small">{errores.telefono}</Form.Text>}</Form.Group></Col>
        </Row><hr className="my-4" /><h2 className="h5 mb-3">Forma de entrega</h2>
        <Form.Check type="radio" name="entrega" id="retiro-tienda" label="Retiro en tienda (gratis)" checked={tipoEntrega === 'retiro'} onChange={() => cambiarEntrega('retiro')} className="mb-2" />
        <Form.Check type="radio" name="entrega" id="despacho-domicilio" label="Despacho a domicilio (simulado $2.990)" checked={tipoEntrega === 'despacho'} onChange={() => cambiarEntrega('despacho')} className="mb-3" />
        {tipoEntrega === 'despacho' && <Row className="g-3 mb-3"><Col md={7}><Form.Group controlId="checkout-direccion"><Form.Label>Dirección</Form.Label><Form.Control name="direccion" autoComplete="street-address" value={datos.direccion} onChange={cambiarDato} />{errores.direccion && <Form.Text className="d-block text-secondary small">{errores.direccion}</Form.Text>}</Form.Group></Col><Col md={5}><Form.Group controlId="checkout-comuna"><Form.Label>Comuna</Form.Label><Form.Control name="comuna" autoComplete="address-level2" value={datos.comuna} onChange={cambiarDato} />{errores.comuna && <Form.Text className="d-block text-secondary small">{errores.comuna}</Form.Text>}</Form.Group></Col></Row>}
        <div className="d-flex flex-wrap gap-2 mt-4"><Button type="submit" variant="success">Revisar datos</Button><Button type="button" variant="outline-secondary" onClick={onVolver}>Volver al carrito</Button></div>
      </Form></Card.Body></Card></Col>
      <Col lg={5}><Card className="cart-summary"><Card.Body><h2 className="h5">Resumen del pedido</h2>{lineas.map(({ producto, cantidad }) => <div className="checkout-item" key={producto.id}><span>{producto.nombre} × {cantidad}</span><strong>{formatoPrecio.format((producto.precioOferta ?? producto.precio) * cantidad)}</strong></div>)}<div className="cart-summary-row"><span>Subtotal</span><span>{formatoPrecio.format(subtotal)}</span></div><div className="cart-summary-row"><span>Entrega</span><span>{costoDespacho ? formatoPrecio.format(costoDespacho) : 'Gratis'}</span></div><div className="cart-summary-row cart-total"><span>Total</span><span>{formatoPrecio.format(subtotal + costoDespacho)}</span></div><p className="small text-secondary mb-0">El costo de despacho es solo demostrativo.</p></Card.Body></Card></Col>
    </Row>
  </Container></main>
}












