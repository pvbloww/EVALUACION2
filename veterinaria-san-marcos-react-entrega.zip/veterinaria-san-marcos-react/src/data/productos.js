// Catálogo simulado: imagen apunta al archivo de public/images y precioOferta define precios promocionales.
export const productos = [
  { id: 'VA001', nombre: 'Vacuna antirrábica canina', categoria: 'Vacunas', precio: 12000, stock: 48, descripcion: 'Vacuna antirrábica obligatoria para perros. Se debe aplicar una vez al año.', imagen: '/images/vacuna-vial.png', imagenAlt: 'Frasco de vacuna veterinaria sin marca' },
  { id: 'VA003', nombre: 'Vacuna bivalente felina', categoria: 'Vacunas', precio: 15000, precioOferta: 13500, stock: 36, descripcion: 'Refuerzo anual para gatos contra las principales enfermedades virales felinas.', imagen: '/images/vacuna-felina-vial.png', imagenAlt: 'Frasco de vacuna veterinaria con tapa azul' },
  { id: 'VA005', nombre: 'Vacuna Bordetella canina', categoria: 'Vacunas', precio: 14000, stock: 22, descripcion: 'Vacuna contra la tos de las perreras, recomendada para perros que asisten a guarderías.', imagen: '/images/vacuna-bordetella-vial.png', imagenAlt: 'Frasco de vacuna veterinaria con tapa verde' },
  { id: 'DE001', nombre: 'Desparasitación interna pequeños (<10 kg)', categoria: 'Desparasitación', precio: 8000, stock: 60, descripcion: 'Tratamiento antiparasitario interno para perros de hasta 10 kg.', imagen: '/images/desparasitacion-tabletas.png', imagenAlt: 'Blíster de tabletas antiparasitarias' },
  { id: 'DE005', nombre: 'Antiparasitario externo (pipeta)', categoria: 'Desparasitación', precio: 7500, stock: 40, descripcion: 'Pipeta antiparasitaria externa para perros y gatos.', imagen: '/images/antiparasitario-pipeta.png', imagenAlt: 'Pipeta antiparasitaria veterinaria' },
  { id: 'ME004', nombre: 'Nexgard (Afoxolaner)', categoria: 'Antiparasitarios', precio: 9500, precioOferta: 8500, stock: 60, descripcion: 'Comprimido masticable que protege contra pulgas y garrapatas.', imagen: '/images/antiparasitario-masticable.png', imagenAlt: 'Comprimido masticable antiparasitario' },
  { id: 'ME006', nombre: 'Revolution Plus', categoria: 'Antiparasitarios', precio: 14500, stock: 35, descripcion: 'Pipeta antiparasitaria para gatos que protege contra varios parásitos.', imagen: '/images/antiparasitario-pipeta.png', imagenAlt: 'Pipeta antiparasitaria veterinaria' },
  { id: 'ME009', nombre: 'Meloxicam 1mg', categoria: 'Medicamentos', precio: 4500, stock: 55, descripcion: 'Antiinflamatorio de uso veterinario. Requiere indicación médica.', imagen: '/images/medicamento-veterinario.png', imagenAlt: 'Frasco de medicamento veterinario y una tableta' },
  { id: 'ME011', nombre: 'Clorhexidina shampoo', categoria: 'Dermatología', precio: 8900, precioOferta: 7900, stock: 25, descripcion: 'Shampoo dermatológico para el cuidado de la piel de perros y gatos.', imagen: '/images/shampoo-dermatologico.png', imagenAlt: 'Botella de shampoo dermatológico veterinario' },
  { id: 'ME021', nombre: 'Omega vet 3-6-9', categoria: 'Suplementos', precio: 9900, stock: 30, descripcion: 'Suplemento con ácidos grasos para mantener un pelaje saludable.', imagen: '/images/suplemento-omega.png', imagenAlt: 'Frasco de suplemento omega veterinario y cápsulas' },
  { id: 'OT001', nombre: 'Corte de uñas', categoria: 'Servicios', precio: 5000, stock: 99, descripcion: 'Servicio de corte de uñas para perros y gatos.', imagen: '/images/servicio-corte-unas.png', imagenAlt: 'Profesional veterinaria realizando corte de uñas a un perro' },
  { id: 'OT003', nombre: 'Microchip identificación', categoria: 'Servicios', precio: 15000, stock: 99, descripcion: 'Implante de microchip de identificación, incluye registro.', imagen: '/images/servicio-microchip.png', imagenAlt: 'Veterinaria escaneando el microchip de identificación de un gato' },
]

export const productosDestacados = productos.slice(0, 3)



