import { productos as productosIniciales } from './productos.js'

const CLAVE_PRODUCTOS = 'veterinaria-san-marcos-productos'

// Lee el catálogo guardado en este navegador; si aún no existe, usa los datos iniciales.
export function obtenerProductos() {
  try {
    const guardados = localStorage.getItem(CLAVE_PRODUCTOS)
    return guardados ? JSON.parse(guardados) : productosIniciales
  } catch {
    return productosIniciales
  }
}

// Guarda la lista completa para simular persistencia sin una base de datos.
export function guardarProductos(productos) {
  localStorage.setItem(CLAVE_PRODUCTOS, JSON.stringify(productos))
}
