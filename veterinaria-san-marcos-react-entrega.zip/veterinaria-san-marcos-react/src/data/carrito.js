const CLAVE_CARRITO = 'veterinaria-san-marcos-carrito'

export function obtenerCarrito() {
  try {
    const guardado = localStorage.getItem(CLAVE_CARRITO)
    const carrito = guardado ? JSON.parse(guardado) : []
    return Array.isArray(carrito) ? carrito : []
  } catch {
    return []
  }
}

function guardarCarrito(carrito) {
  localStorage.setItem(CLAVE_CARRITO, JSON.stringify(carrito))
  return carrito.reduce((total, item) => total + item.cantidad, 0)
}

export function obtenerCantidadCarrito() {
  return obtenerCarrito().reduce((total, item) => total + item.cantidad, 0)
}

export function agregarProductoAlCarrito(productoId) {
  const carrito = obtenerCarrito()
  const existente = carrito.find((item) => item.productoId === productoId)
  const nuevoCarrito = existente
    ? carrito.map((item) => item.productoId === productoId ? { ...item, cantidad: item.cantidad + 1 } : item)
    : [...carrito, { productoId, cantidad: 1 }]
  return guardarCarrito(nuevoCarrito)
}

export function actualizarCantidadProducto(productoId, cantidad) {
  const carrito = obtenerCarrito().map((item) => item.productoId === productoId ? { ...item, cantidad } : item)
  return guardarCarrito(carrito)
}

export function quitarProductoDelCarrito(productoId) {
  const carrito = obtenerCarrito().filter((item) => item.productoId !== productoId)
  return guardarCarrito(carrito)
}

export function vaciarCarrito() {
  return guardarCarrito([])
}
