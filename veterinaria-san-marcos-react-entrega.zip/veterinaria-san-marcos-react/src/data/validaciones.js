// Revisa los datos del checkout y devuelve mensajes para los campos incorrectos.
export function validarDatos(datos, tipoEntrega) {
  const errores = {}
  const nombre = datos.nombre.trim()
  const correo = datos.correo.trim()
  const telefono = datos.telefono.replaceAll(' ', '').replaceAll('+', '').replaceAll('-', '')

  // Exige al menos 3 caracteres y evita que el nombre sean solo números.
  if (nombre.length < 3 || !isNaN(Number(nombre))) errores.nombre = 'Escribe tu nombre (mínimo 3 caracteres).'
  // Comprueba de forma simple que el correo incluya @ y un punto.
  if (!correo.includes('@') || !correo.includes('.')) errores.correo = 'El correo debe incluir @ y un punto.'
  // Comprueba que el teléfono tenga solo números y al menos 8 dígitos.
  if (isNaN(Number(telefono)) || telefono.length < 8) errores.telefono = 'El teléfono debe tener al menos 8 números.'
  // Solo revisa dirección y comuna cuando se eligió despacho.
  if (tipoEntrega === 'despacho') {
    // Exige una dirección de al menos 5 caracteres.
    if (datos.direccion.trim().length < 5) errores.direccion = 'Escribe una dirección (mínimo 5 caracteres).'
    // Exige escribir al menos 2 caracteres para la comuna.
    if (datos.comuna.trim().length < 2) errores.comuna = 'Escribe el nombre de tu comuna.'
  }
  return errores
}
