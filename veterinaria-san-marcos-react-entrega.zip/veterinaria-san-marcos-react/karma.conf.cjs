const path = require('path')

module.exports = (config) => {
  config.set({
    basePath: '',
    frameworks: ['jasmine', 'webpack'],
    files: [{ pattern: 'tests/**/*.spec.js', watched: false }],
    preprocessors: { 'tests/**/*.spec.js': ['webpack'] },
    webpack: {
      mode: 'development',
      module: {
        rules: [{
          test: /src[\\/]data[\\/](validaciones|carrito)\.js$/,
          include: path.resolve(__dirname, 'src'),
          use: { loader: 'babel-loader', options: { plugins: ['istanbul'] } },
        }],
      },
      stats: 'errors-only',
    },
    reporters: ['progress', 'coverage'],
    browsers: ['ChromeHeadless'],
    singleRun: true,
    coverageReporter: {
      dir: path.join(__dirname, 'coverage'),
      reporters: [{ type: 'html', subdir: 'html' }, { type: 'text-summary' }],
    },
    plugins: [
      require('karma-jasmine'),
      require('karma-webpack'),
      require('karma-chrome-launcher'),
      require('karma-coverage'),
    ],
  })
}
