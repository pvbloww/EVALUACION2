# ERS V2 — Veterinaria San Marcos

**Versión:** 2.0  
**Tipo de sistema:** Aplicación web académica de comercio veterinario  
**Tecnologías:** React, Vite, React-Bootstrap y JavaScript

## 1. Propósito

Este documento especifica los requisitos funcionales y no funcionales de la aplicación Veterinaria San Marcos. La aplicación permite explorar un catálogo veterinario, gestionar un carrito, completar un flujo de compra demostrativo y administrar productos desde un acceso separado.

## 2. Alcance y límites

El sistema es una demostración de una tienda veterinaria. El catálogo, el carrito y los cambios administrativos se guardan localmente en el navegador. No existe conexión a una base de datos ni a un servidor de autenticación. El checkout no procesa pagos ni envía pedidos reales.

## 3. Usuarios

- **Cliente:** explora productos y servicios, usa ofertas, agrega artículos al carrito y completa los pasos demostrativos de compra.
- **Administrador de demostración:** inicia sesión con credenciales definidas en el proyecto y gestiona el catálogo mediante operaciones CRUD.

## 4. Requisitos funcionales

| ID | Requisito | Criterio de aceptación |
|---|---|---|
| RF-01 | Mostrar una página de inicio con información de la veterinaria y productos destacados. | La portada presenta el contenido y permite ir al catálogo. |
| RF-02 | Mostrar productos y servicios con nombre, categoría, descripción, precio e imagen. | Cada tarjeta muestra los datos del producto y una imagen correspondiente. |
| RF-03 | Buscar y filtrar el catálogo. | El usuario puede buscar por texto y filtrar por categoría. |
| RF-04 | Mostrar una vista de ofertas. | La vista presenta solo productos que tienen precio promocional. |
| RF-05 | Agregar productos al carrito y modificar cantidades. | El carrito muestra artículos, cantidades y total actualizado. |
| RF-06 | Quitar un producto o vaciar el carrito. | La lista y el contador del carrito se actualizan. |
| RF-07 | Conservar el carrito y el catálogo administrado en el navegador. | Los datos se guardan y vuelven a leerse mediante `localStorage`. |
| RF-08 | Validar datos de contacto y despacho antes de revisar el pedido. | Se muestran mensajes junto a los campos incorrectos; dirección y comuna se revisan si se elige despacho. |
| RF-09 | Mostrar un resumen de compra antes de confirmar. | El resumen presenta contacto, entrega, productos, subtotal y total. |
| RF-10 | Mostrar resultado exitoso y fallido de compra simulada. | El usuario puede mostrar ambos resultados; no se procesa un pago real. |
| RF-11 | Solicitar inicio de sesión antes de mostrar la administración. | Las credenciales de demostración permiten entrar; credenciales incorrectas muestran un mensaje. |
| RF-12 | Crear, consultar, editar y eliminar productos en administración. | Cada operación actualiza el catálogo compartido con la tienda. |
| RF-13 | Permitir cerrar la sesión de administración. | Al cerrar sesión, se vuelve a la portada y se requiere ingresar de nuevo. |

## 5. Requisitos no funcionales

- **RNF-01 Responsividad:** las vistas se adaptan a pantallas pequeñas y grandes mediante Bootstrap.
- **RNF-02 Usabilidad:** navegación, formularios y botones usan etiquetas comprensibles en español.
- **RNF-03 Mantenibilidad:** la interfaz se organiza en componentes React y los datos simulados se separan de las vistas.
- **RNF-04 Persistencia local:** el navegador conserva carrito y productos administrados mediante `localStorage`.
- **RNF-05 Alcance de seguridad:** el login local es únicamente demostrativo; no protege información frente a usuarios técnicos ni sustituye autenticación de servidor.

## 6. Reglas de negocio

- Los productos con `precioOferta` se muestran en la vista de ofertas y usan ese precio en el catálogo y carrito.
- El despacho agrega un costo demostrativo de $2.990; el retiro en tienda no agrega costo.
- Para el despacho se requieren dirección y comuna.
- Vaciar el carrito elimina todos sus artículos guardados localmente.
- La compra y su resultado son simulaciones, sin cobros ni envío de pedidos.

## 7. Referencia de implementación

| Área | Archivo principal |
|---|---|
| Navegación y vistas | `src/App.jsx` |
| Inicio de sesión administrativo | `src/AdminLogin.jsx` |
| Administración CRUD | `src/Admin.jsx` |
| Catálogo y ofertas | `src/Catalogo.jsx`, `src/data/productos.js`, `src/data/catalogo.js` |
| Carrito | `src/Carrito.jsx`, `src/data/carrito.js` |
| Checkout y validaciones | `src/Checkout.jsx` |
| Estilos responsivos | `src/App.css`, `src/index.css` |

## 8. Restricciones y pendientes

- Las credenciales administrativas están escritas en el código y son solo para la presentación académica.
- El almacenamiento es local al navegador; no hay sincronización entre equipos.
- No se implementa pago real, despacho real ni conexión con servicios externos.
- Las pruebas automatizadas y su reporte de cobertura quedan pendientes de confirmar el framework solicitado por el docente, porque los materiales disponibles indican herramientas diferentes.
