# Veterinaria San Marcos

Proyecto académico de tienda veterinaria desarrollado con React, Vite y Bootstrap. Usa productos simulados en JavaScript y guarda el carrito y los cambios administrativos en `localStorage`; no está conectado a una base de datos ni procesa pagos reales.

## Recorrido de la aplicación

- `src/App.jsx`: navegación y selección de las vistas.
- `src/Catalogo.jsx`: búsqueda, filtros por categoría, ofertas y tarjetas.
- `src/Carrito.jsx`: cantidades, eliminación, vaciado y total.
- `src/Checkout.jsx`: validación básica de datos, resumen y resultado simulado.
- `src/AdminLogin.jsx`: acceso de demostración separado para administración.
- `src/Admin.jsx`: tabla y formulario para agregar, editar y eliminar productos.
- `src/data/productos.js`: catálogo de ejemplo y precios.
- `src/data/catalogo.js`: lectura y guardado del catálogo en el navegador.
- `src/data/carrito.js`: operaciones del carrito guardadas en `localStorage`.
- `src/App.css`: estilos de secciones, tarjetas, catálogo, carrito e imágenes.
- `src/index.css`: tipografía, fondo y colores globales.
- `public/images/`: imágenes utilizadas por la aplicación.

## Ubicar colores e imágenes

Los colores principales están en las variables `:root` de `src/index.css`: `--verde` (`#2f7a5f`), `--verde-oscuro` (`#205942`) y `--naranjo` (`#f2a541`). Los estilos específicos están en `src/App.css`; por ejemplo, `.hero-section` define la portada, `.site-navbar` el encabezado y `.product-card` las tarjetas.

Las imágenes de producto se asignan en `src/data/productos.js`, en `imagen` e `imagenAlt`, y sus archivos están en `public/images/`. La imagen principal de la portada se usa desde `src/App.jsx`.

## Ejecución local

Con Node.js y pnpm instalados, desde esta carpeta:

```sh
pnpm install
pnpm dev
```

Para generar la versión de producción:

```sh
pnpm build
```

## Alcance académico y pendientes de entrega

El login usa credenciales fijas de demostración (`admin@sanmarcos.cl` / `admin123`) y solo simula una sesión en el navegador; no es autenticación segura de servidor. La aplicación incluye navegación, catálogo responsivo con Bootstrap, ofertas, persistencia local del carrito y del catálogo, administración CRUD demostrativa con pantalla de acceso separada, checkout con validaciones básicas y resultados simulados.

La pauta principal especifica Jasmine y Karma; algunos materiales de clases mencionan Vitest y Testing Library. Esta versión sigue la pauta principal. La suite se ejecuta con `pnpm test` y el reporte HTML de cobertura queda en `coverage/html/`. El documento ERS V2 está en `docs/ERS_V2.md`. Falta publicar el enlace público de GitHub y entregar el proyecto comprimido.



