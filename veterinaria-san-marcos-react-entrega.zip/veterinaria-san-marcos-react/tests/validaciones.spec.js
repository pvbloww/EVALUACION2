import { validarDatos } from '../src/data/validaciones.js'

describe('validarDatos', () => {
  const datosCorrectos = {
    nombre: 'Camila Pérez',
    correo: 'camila@correo.cl',
    telefono: '56912345678',
    direccion: 'Av. Central 123',
    comuna: 'Rancagua',
  }

  it('acepta datos correctos para retiro', () => {
    expect(validarDatos(datosCorrectos, 'retiro')).toEqual({})
  })

  it('marca nombre corto, correo incompleto y teléfono corto', () => {
    const datos = { ...datosCorrectos, nombre: '88', correo: 'camila-correo', telefono: '1234' }
    const errores = validarDatos(datos, 'retiro')
    expect(errores.nombre).toBeTruthy()
    expect(errores.correo).toBeTruthy()
    expect(errores.telefono).toBeTruthy()
  })

  it('pide dirección y comuna solamente para despacho', () => {
    const datos = { ...datosCorrectos, direccion: '', comuna: '' }
    expect(validarDatos(datos, 'retiro')).toEqual({})
    const errores = validarDatos(datos, 'despacho')
    expect(errores.direccion).toBeTruthy()
    expect(errores.comuna).toBeTruthy()
  })
})
