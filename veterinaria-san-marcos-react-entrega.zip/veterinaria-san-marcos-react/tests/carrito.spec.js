import { agregarProductoAlCarrito, actualizarCantidadProducto, obtenerCarrito, quitarProductoDelCarrito, vaciarCarrito } from '../src/data/carrito.js'

describe('carrito guardado en localStorage', () => {
  beforeEach(() => localStorage.clear())

  it('agrega un producto y aumenta la cantidad si ya existe', () => {
    expect(agregarProductoAlCarrito('VA001')).toBe(1)
    expect(agregarProductoAlCarrito('VA001')).toBe(2)
    expect(obtenerCarrito()).toEqual([{ productoId: 'VA001', cantidad: 2 }])
  })

  it('actualiza la cantidad de un producto', () => {
    agregarProductoAlCarrito('VA001')
    actualizarCantidadProducto('VA001', 3)
    expect(obtenerCarrito()[0].cantidad).toBe(3)
  })

  it('quita un producto del carrito', () => {
    agregarProductoAlCarrito('VA001')
    quitarProductoDelCarrito('VA001')
    expect(obtenerCarrito()).toEqual([])
  })

  it('vacía todos los productos guardados', () => {
    agregarProductoAlCarrito('VA001')
    agregarProductoAlCarrito('VA003')
    vaciarCarrito()
    expect(obtenerCarrito()).toEqual([])
  })
})
